package airportsProject;

import libs.EdgeWeightedDigraph;

public class AirMap extends EdgeWeightedDigraph {
    public AirMap(int V) {
        super(V);
    }

}
